# # import by PB

# from django.urls import path
# from . import views 

# urlpatterns = [
#     #this will redirect to index of views.py
#     path("", views.func , name = "HomePage"),
#     path("about/" , views.about , name= "AboutUs"),
#     path("contact/" , views.contact , name= "ContactUs"),
#     path("tracker/" , views.tracker , name= "TrackingStatus"),
#     path("search/" , views.search , name= "Search"),
#     path("productview/" , views.productView , name= "ProductView"),
#     path("checkout/" , views.checkout , name= "CheckOut"),
    
# ]


from django.urls import path
from . import views

urlpatterns = [
    path("", views.index, name="HomePage"),
    path("about/", views.about, name="AboutUs"),
    path("contact/", views.contact, name="ContactUs"),
    path("tracker/", views.tracker, name="TrackingStatus"),
    path("search/", views.search, name="Search"),
    path("productview/<int:myid>", views.productView, name="ProductView"),
    path("checkout/", views.checkout, name="Checkout"),
]
